<?php
/*
 Plugin Name: B Plugin
 Plugin URI: http://bitbytes.io
 Description: Plugin with auto-updates from external URL/Repository using Github
 Author: BitBytes
 Version: 1.2.1
 */